<?php
header('Content-Type: text/txt; charset=UTF-8');
$nombre = '';
$apellido = '';
$direccion = '';

switch ($_REQUEST['ine'] ) {
  case '1':
    $nombre = 'Juan';
    $apellido = 'Rodríguez';
    $direccion = '15 Oriente 123';
    break;
  case '2':
    $nombre = 'Ana Luisa';
    $apellido = 'Maldonado';
    $direccion = '12 Sur 245';
    break;
  case '3':
    $nombre = 'Laura';
    $apellido = 'Puebla';
    $direccion = 'Carmen Serdán 785';
    break;
  default:
    $nombre = 'No encontrado';
    $apellido = 'No encontrado';
    $direccion = 'No encontrado';
}

echo "{
        'nombre':'$nombre',
        'apellido':'$apellido',
        'direccion':'$direccion'
      }";
?>